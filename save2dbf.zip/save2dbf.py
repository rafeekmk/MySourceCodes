#
# save2dbf() function executes and saves the result set of a query to a dbf file
#
# raf2code@gmail.com
# 2018-oct-10

import dbf  
import pypyodbc

def save2dbf(rs_cur, dbf_cur, sql, f_name):
# rs_cur : cursor object to execute the sql. Needs not be dbf. 
# dbf_cur: cursor object for dbf
# sql    : the sql query to be executed using rs_cur 
# f_name : the target file where the result would be saved

	cols = cur.execute(sql).description

	c1 = f_name # "f:/tt1.dbf"
	c2 = ''

	for col in cols:
	#	print(col)
		col_type = str(col[1]).strip('<class ')
		if col_type == "'bool'>":
			col_type = 'L'
		if col_type == "'str'>":
			col_type = 'C(' + str(col[2]) + ')'
		if col_type == "'datetime.date'>":
			col_type = 'D'
		if col_type == "'decimal.Decimal'>":
			col_type = 'N(' + str(col[2]) + ','+ str(col[5]) + ')'
		c2= c2 +  col[0] + ' ' + col_type + '; '

	c2 = c2.strip(';\t') 

#	print('\n',c2,'\n')

	t1 = dbf.Table(c1, c2)
	t1.open(mode=dbf.READ_WRITE)

	#Index creation is to be explored

	rows = cur.execute(sql)

	for r in rows:
		t1.append(r)

fc = pypyodbc.connect('DSN=fleet')
cur = fc.cursor()
save2dbf(cur, cur, 'select * from sample.dbf', 'f://t2.dbf')

